import React, { useEffect, useState } from 'react';
import AnimeCard from '../components/AnimeCard';

type Anime = {
  id: string;
  title: string;
  image: string;
};

export default function Home() {
  const [animeList, setAnimeList] = useState<Anime[]>([]);

  useEffect(() => {
    fetch('/api/anime')
      .then((res) => res.json())
      .then((data) => setAnimeList(data));
  }, []);

  return (
    <main className="min-h-screen bg-gray-900 text-white">
      <header className="py-6 px-4 border-b border-gray-800 flex items-center justify-between">
        <h1 className="text-3xl font-bold text-purple-400">AniStream</h1>
        <nav>
          <a href="#" className="text-gray-300 hover:text-white mx-2">Home</a>
          <a href="/anime-list" className="text-gray-300 hover:text-white mx-2">Anime List</a>
        </nav>
      </header>
      <section className="py-16 px-4 text-center">
        <h2 className="text-4xl font-extrabold mb-4">Watch Anime Online, Free & Updated Daily</h2>
        <p className="text-lg text-gray-300 mb-8">Inspired by 9anime and Animotv. For educational use only.</p>
        <input
          type="text"
          placeholder="Search anime..."
          className="w-full max-w-md px-4 py-2 rounded bg-gray-800 text-white border border-gray-700 focus:outline-none focus:ring-2 focus:ring-purple-500"
        />
      </section>
      <section className="px-4 pb-16">
        <h3 className="text-2xl font-bold mb-6">Latest Anime</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-6">
          {animeList.length === 0 ? (
            Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="bg-gray-800 rounded shadow p-4 animate-pulse h-64" />
            ))
          ) : (
            animeList.map((anime) => (
              <AnimeCard key={anime.id} title={anime.title} image={anime.image} href={`/anime/${anime.id}`} />
            ))
          )}
        </div>
      </section>
    </main>
  );
} 