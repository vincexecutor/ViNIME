import type { NextApiRequest, NextApiResponse } from 'next';

const demoAnime = [
  {
    id: '1',
    title: 'Attack on Titan',
    image: 'https://static.anistream.edu/demo/aot.jpg',
  },
  {
    id: '2',
    title: 'Demon Slayer',
    image: 'https://static.anistream.edu/demo/demonslayer.jpg',
  },
  {
    id: '3',
    title: 'Jujutsu Kaisen',
    image: 'https://static.anistream.edu/demo/jujutsu.jpg',
  },
  {
    id: '4',
    title: 'One Piece',
    image: 'https://static.anistream.edu/demo/onepiece.jpg',
  },
];

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  res.status(200).json(demoAnime);
} 