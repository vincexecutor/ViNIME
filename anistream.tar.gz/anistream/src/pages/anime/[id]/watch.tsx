import React from 'react';
import { useRouter } from 'next/router';

const demoAnime = [
  {
    id: '1',
    title: 'Attack on Titan',
    video: 'https://www.w3schools.com/html/mov_bbb.mp4',
  },
  {
    id: '2',
    title: 'Demon Slayer',
    video: 'https://www.w3schools.com/html/movie.mp4',
  },
  {
    id: '3',
    title: 'Jujutsu Kaisen',
    video: 'https://www.w3schools.com/html/mov_bbb.mp4',
  },
  {
    id: '4',
    title: 'One Piece',
    video: 'https://www.w3schools.com/html/movie.mp4',
  },
];

export default function WatchAnime() {
  const router = useRouter();
  const { id } = router.query;
  const animeId = Array.isArray(id) ? id[0] : id;
  const anime = demoAnime.find((a) => a.id === animeId);

  if (!anime) {
    return <div className="text-white p-8">Anime not found.</div>;
  }

  return (
    <main className="min-h-screen bg-gray-900 text-white">
      <header className="py-6 px-4 border-b border-gray-800 flex items-center justify-between">
        <h1 className="text-3xl font-bold text-purple-400">AniStream</h1>
        <nav>
          <a href="/" className="text-gray-300 hover:text-white mx-2">Home</a>
          <a href="/anime-list" className="text-gray-300 hover:text-white mx-2">Anime List</a>
        </nav>
      </header>
      <section className="py-16 px-4 flex flex-col items-center">
        <h2 className="text-3xl font-extrabold mb-6">{anime.title} - Episode 1</h2>
        <video controls className="w-full max-w-3xl rounded shadow-lg bg-black">
          <source src={anime.video} type="video/mp4" />
          Your browser does not support the video tag.
        </video>
      </section>
    </main>
  );
} 