import React from 'react';
import { useRouter } from 'next/router';

const demoAnime = [
  {
    id: '1',
    title: 'Attack on Titan',
    image: 'https://static.anistream.edu/demo/aot.jpg',
    description: 'Humans fight for survival against man-eating giants.'
  },
  {
    id: '2',
    title: 'Demon Slayer',
    image: 'https://static.anistream.edu/demo/demonslayer.jpg',
    description: 'A boy becomes a demon slayer to save his sister.'
  },
  {
    id: '3',
    title: 'Jujutsu Kaisen',
    image: 'https://static.anistream.edu/demo/jujutsu.jpg',
    description: 'A student fights curses with supernatural powers.'
  },
  {
    id: '4',
    title: 'One Piece',
    image: 'https://static.anistream.edu/demo/onepiece.jpg',
    description: 'Pirates search for the ultimate treasure.'
  },
];

export default function AnimeDetails() {
  const router = useRouter();
  const { id } = router.query;
  const animeId = Array.isArray(id) ? id[0] : id;
  const anime = demoAnime.find((a) => a.id === animeId);

  if (!anime) {
    return <div className="text-white p-8">Anime not found.</div>;
  }

  return (
    <main className="min-h-screen bg-gray-900 text-white">
      <header className="py-6 px-4 border-b border-gray-800 flex items-center justify-between">
        <h1 className="text-3xl font-bold text-purple-400">AniStream</h1>
        <nav>
          <a href="/" className="text-gray-300 hover:text-white mx-2">Home</a>
          <a href="/anime-list" className="text-gray-300 hover:text-white mx-2">Anime List</a>
        </nav>
      </header>
      <section className="py-16 px-4 flex flex-col md:flex-row items-center md:items-start gap-8">
        <img src={anime.image} alt={anime.title} className="w-64 h-96 object-cover rounded shadow" />
        <div>
          <h2 className="text-4xl font-extrabold mb-4">{anime.title}</h2>
          <p className="text-lg text-gray-300 mb-8">{anime.description}</p>
          <a href={`/anime/${anime.id}/watch`}>
            <button className="px-6 py-2 bg-purple-600 rounded text-white font-bold hover:bg-purple-700">Watch Now</button>
          </a>
        </div>
      </section>
    </main>
  );
} 