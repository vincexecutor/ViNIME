import React from 'react';

type AnimeCardProps = {
  title: string;
  image: string;
  href: string;
};

export default function AnimeCard({ title, image, href }: AnimeCardProps) {
  return (
    <a href={href} className="block bg-gray-800 rounded shadow hover:scale-105 transition-transform overflow-hidden">
      <img src={image} alt={title} className="w-full h-40 object-cover" />
      <div className="p-2">
        <h4 className="text-sm font-semibold text-white truncate">{title}</h4>
      </div>
    </a>
  );
} 